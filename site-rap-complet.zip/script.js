function verifier(reponse) {
  const resultat = document.getElementById("resultat");

  if (reponse === "newyork") {
    resultat.textContent = "✅ Bonne réponse ! Le rap est né à New York.";
  } else {
    resultat.textContent = "❌ Pas exactement. La bonne réponse est New York.";
  }
}
