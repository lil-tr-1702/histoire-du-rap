function verifier(reponse) {
  const resultat = document.getElementById("resultat");

  if (reponse === "newyork") {
    resultat.textContent = "✅ Bonne réponse ! Le rap est né dans le Bronx, à New York.";
  } else {
    resultat.textContent = "❌ Pas tout à fait. La bonne réponse est New York.";
  }
}
